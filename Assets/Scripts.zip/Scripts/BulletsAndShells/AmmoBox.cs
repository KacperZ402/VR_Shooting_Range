using UnityEngine;

/// <summary>
/// Dzia�a jak pude�ko z amunicj�. Posiada publiczn� metod�
/// 'OpenBox', kt�ra po wywo�aniu wyrzuca zawarto�� z puli
/// w zorganizowanej siatce i niszczy pude�ko.
/// </summary>
public class AmmoBox : MonoBehaviour
{
    [Header("Konfiguracja Pude�ka")]
    [Tooltip("Prefab naboju (z komponentem Bullet), kt�ry ma zosta� pobrany z puli.")]
    public GameObject ammoPrefab;

    [Header("Ustawienia Siatki (Grid)")]
    [Tooltip("Liczba kolumn w siatce (O� X)")]
    public int gridColumns = 5;

    [Tooltip("Liczba rz�d�w w siatce (O� Y/Z)")]
    public int gridRows = 2;

    [Tooltip("Odst�p mi�dzy nabojami w siatce (w metrach).")]
    public float gridSpacing = 0.05f; // 5 cm

    private AmmoPoolManager ammoPool;

    // Pobieramy referencj� do puli przy starcie
    void Awake()
    {
        ammoPool = AmmoPoolManager.Instance;

        if (ammoPool == null)
        {
            Debug.LogError("[AmmoBox] Nie znaleziono AmmoPoolManager na scenie! To pude�ko nie b�dzie dzia�a�.", this);
        }
    }

    /// <summary>
    /// Publiczna funkcja, kt�r� mo�esz wywo�a�, aby "otworzy�" pude�ko.
    /// Wyrzuca naboje i niszczy ten obiekt.
    /// </summary>
    public void OpenBox()
    {
        if (ammoPool == null)
        {
            Debug.LogError("[AmmoBox] Pr�ba otwarcia pude�ka, ale nie znaleziono AmmoPoolManager!", this);
            Destroy(gameObject);
            return;
        }

        if (ammoPrefab == null)
        {
            Debug.LogError("[AmmoBox] Nie przypisano 'ammoPrefab'! Niszcz�...", this);
            Destroy(gameObject);
            return;
        }

        // 1. Wyrzu� zawarto��
        SpawnRoundsInGrid();

        // 2. Zniszcz pude�ko
        Destroy(gameObject);
    }

    /// <summary>
    /// Wewn�trzna logika pobierania i uk�adania naboj�w w siatce.
    /// </summary>
    private void SpawnRoundsInGrid()
    {
        int totalSpawned = 0;
        int totalToSpawn = gridColumns * gridRows;

        if (totalToSpawn <= 0) return;

        // --- Obliczanie centrowania siatki ---
        // Obliczamy ca�kowit� szeroko�� i g��boko�� siatki
        float gridWidth = (gridColumns - 1) * gridSpacing;
        float gridDepth = (gridRows - 1) * gridSpacing;

        // Znajdujemy punkt startowy (lewy dolny r�g), aby siatka by�a wy�rodkowana
        // na obiekcie AmmoBox. Dodajemy ma�y offset Y, aby naboje nie kolidowa�y z pod�og�.
        Vector3 startOffset = new Vector3(-gridWidth / 2.0f, 0.01f, -gridDepth / 2.0f);

        for (int y = 0; y < gridRows; y++)
        {
            for (int x = 0; x < gridColumns; x++)
            {
                // A. Pobierz nab�j z puli
                GameObject round = ammoPool.GetRound(ammoPrefab);
                if (round == null)
                {
                    Debug.LogWarning($"[AmmoBox] Pula zwr�ci�a 'null'. Spawniono {totalSpawned} z {totalToSpawn} naboj�w.", this);
                    return; // Przerwij, je�li pula jest pusta
                }

                // B. Oblicz pozycj� lokaln� dla tego naboju
                Vector3 localPos = startOffset + new Vector3(x * gridSpacing, 0, y * gridSpacing);

                // C. Przekszta�� pozycj� lokaln� na �wiatow�, uwzgl�dniaj�c rotacj� pude�ka
                Vector3 spawnPosition = transform.position + (transform.rotation * localPos);

                // D. Ustaw pozycj� i rotacj� naboju (taka sama jak pude�ka)
                round.transform.position = spawnPosition;
                round.transform.rotation = transform.rotation;

                // Usun�li�my "wyrzut" fizyczny - naboje po prostu pojawi� si� u�o�one
                totalSpawned++;
            }
        }

        Debug.Log($"[AmmoBox] Otwarto i wyrzucono {totalSpawned} naboj�w typu {ammoPrefab.name} w siatce.", this);
    }
}