using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Zarz�dza pul� obiekt�w POCISK�W (tych, kt�re lataj�),
/// aby unikn�� kosztownego Instantiate/Destroy przy strzale.
/// </summary>
public class BulletPoolManager : MonoBehaviour
{
    public static BulletPoolManager Instance { get; private set; }

    private Dictionary<string, Queue<GameObject>> pools = new Dictionary<string, Queue<GameObject>>();
    private Transform poolParent;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
            poolParent = new GameObject("BulletPool").transform; // Inna nazwa dla porz�dku
            poolParent.SetParent(this.transform);
        }
    }

    /// <summary>
    /// Zwraca pocisk do puli.
    /// </summary>
    public void ReturnBullet(GameObject bulletInstance)
    {
        // "Czy�cimy" nazw�, aby znale�� klucz prefabu
        string dirtyName = bulletInstance.name;
        string key = dirtyName.Split('(')[0].Trim();

        if (string.IsNullOrEmpty(key))
        {
            Destroy(bulletInstance);
            return;
        }

        if (!pools.ContainsKey(key))
        {
            pools[key] = new Queue<GameObject>();
        }

        bulletInstance.SetActive(false);
        bulletInstance.transform.SetParent(poolParent);
        pools[key].Enqueue(bulletInstance);
    }

    /// <summary>
    /// Pobiera instancj� pocisku z puli.
    /// </summary>
    public GameObject GetBullet(GameObject bulletPrefab)
    {
        string key = bulletPrefab.name;
        GameObject bulletInstance;

        if (pools.ContainsKey(key) && pools[key].Count > 0)
        {
            bulletInstance = pools[key].Dequeue();
            bulletInstance.transform.SetParent(null);
        }
        else
        {
            bulletInstance = Instantiate(bulletPrefab);
            // Nie musimy si� martwi� nazw� (1), bo ReturnBullet j� czy�ci
        }

        bulletInstance.SetActive(true);
        return bulletInstance;
    }
}